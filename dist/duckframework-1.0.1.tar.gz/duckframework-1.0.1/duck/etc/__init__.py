"""
etc - Module for Duck configuration files, proxy modules and static python files.
"""
