from .media import mediafiles_view, async_mediafiles_view # noqa: F401
from .static import staticfiles_view, async_staticfiles_view # noqa: F401
from .sitemap import sitemap_view, async_sitemap_view # noqa: F401
