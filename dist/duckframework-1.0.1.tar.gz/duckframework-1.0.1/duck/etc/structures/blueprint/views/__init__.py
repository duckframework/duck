"""
Import your views here, make sure to include them in __all__ list. This
This ensures your views don't get removed when different formatters
formatting this python file.  

**Note:** Adding views to __all__ is not mandatory.
"""
# eg: from .home import home_view

__all__ = [
    # Your views here, e.g. "home_view"
]
