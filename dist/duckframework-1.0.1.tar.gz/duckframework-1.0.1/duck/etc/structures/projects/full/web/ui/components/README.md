Use this folder to store all your UI components for the root application.

You can delete the templates folder `../templates` if you are not using templates at all.
