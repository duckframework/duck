Use this folder for global staticfiles for the application.
