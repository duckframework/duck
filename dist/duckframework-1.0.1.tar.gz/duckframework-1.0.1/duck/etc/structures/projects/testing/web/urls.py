urlpatterns = [] # No URL configuration
