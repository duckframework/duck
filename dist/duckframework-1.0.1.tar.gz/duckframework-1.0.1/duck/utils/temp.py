class Temp(object):
    """Temporary object to store data"""
