# Folder contains your server SSL credentials
**Note**: Default credentials are for the `localhost` domain, but they have been self generated using **Duck** `ssl-gen` so web browsers might have a hard time trusting these credentials.
