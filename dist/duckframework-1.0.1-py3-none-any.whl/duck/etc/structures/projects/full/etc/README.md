Use this folder to store all your configuration and other external files.
