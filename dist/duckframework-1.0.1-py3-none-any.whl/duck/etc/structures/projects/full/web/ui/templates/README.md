Use this folder for defining templates for the root application.

You can delete the other folders `../pages` and `../components` if you are not using UI components.
