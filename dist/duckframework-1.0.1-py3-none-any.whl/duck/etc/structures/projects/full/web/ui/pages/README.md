Use this folder for defining your Page components for the root application.

You can delete the templates folder `../templates` if you are not using templates at all.
