# Duck project has been setup
## Write your web application documentation here.