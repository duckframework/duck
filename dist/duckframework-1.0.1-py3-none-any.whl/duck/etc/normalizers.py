# All normalizers as modulename.ClassName in string format

normalizers = ["duck.http.normalizers.URLNormalizer"]
