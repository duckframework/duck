"""
Provide Duck utilities, functions and useful tools.
"""

# Notes
# - All utility modules must not depend on Duck settings or they must 
#   not fail when imported outside the Duck project.
