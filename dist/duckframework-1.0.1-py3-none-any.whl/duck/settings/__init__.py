from duck.settings.settings import SETTINGS

__all__ = ["SETTINGS"]
