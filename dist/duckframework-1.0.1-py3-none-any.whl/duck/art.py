"""
This provides accessibility to Duck Ansi/Ascii Art.
"""

duck_art_large = """
██████╗  ██╗   ██╗ ██████╗██╗  ██╗
██╔══██╗ ██║   ██║██╔════╝██║ ██╔╝
██║  ██║ ██║   ██║██║     █████╔╝ 
██║  ██║ ██║   ██║██║     ██╔═██╗ 
██████╔╝╚██████╔╝╚██████╗ ██║  ██╗
╚═════╝  ╚═════╝  ╚═════╝ ╚═╝  ╚═╝
"""

duck_art_small = """
   __
<(o )___
 (  ._> /
  `----'
"""


def display_duck_art():
    bold_start = "\033[1m"
    bold_end = "\033[0m"
    print(bold_start + duck_art_small + bold_end)


if __name__ == "__main__":
    display_duck_art()
