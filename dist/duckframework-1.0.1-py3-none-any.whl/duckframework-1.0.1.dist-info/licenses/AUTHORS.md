# Authors

Brian Musakwa <digreatbrian@gmail.com>

## Sole Developer and Owner
Brian Musakwa is the sole developer and owner of this software.

## Acknowledgements
Special thanks to Guido van Rossum for creating Python, which made this project possible.

## Project History
Duck was created in the early days of March 2024.
